from sqlalchemy.orm import sessionmaker
from database import DeliveryRequest, Vehicle, DeliveryStatus
from database_manager import init_db
from datetime import datetime, timedelta
from database_manager import init_db

SessionLocal = init_db()  # Now SessionLocal is a session factory
session = SessionLocal()  # This creates a new session object


# Add sample vehicles
vehicle1 = Vehicle(
    id="V001",
    capacity=100.0,
    current_latitude=12.9716,
    current_longitude=77.5946,
    available_time=datetime.now(),
    status="available"
)

vehicle2 = Vehicle(
    id="V002",
    capacity=150.0,
    current_latitude=13.0827,
    current_longitude=80.2707,
    available_time=datetime.now(),
    status="available"
)

# Add sample delivery requests
delivery1 = DeliveryRequest(
    id="D001",
    latitude=12.9352,
    longitude=77.6245,
    time_window_start=datetime.now() + timedelta(minutes=30),
    time_window_end=datetime.now() + timedelta(hours=2),
    load_size=50.0,
    priority=1,
    status=DeliveryStatus.PENDING
)

delivery2 = DeliveryRequest(
    id="D002",
    latitude=13.0098,
    longitude=77.5556,
    time_window_start=datetime.now() + timedelta(minutes=45),
    time_window_end=datetime.now() + timedelta(hours=3),
    load_size=70.0,
    priority=2,
    status=DeliveryStatus.PENDING
)

# Commit to DB
session.add_all([vehicle1, vehicle2, delivery1, delivery2])
session.commit()

print("Sample data inserted successfully!")
session.close()
