from database import Base, DeliveryRequest, Vehicle
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
from config import DATABASE_URL
from sqlalchemy import inspect

engine = create_engine(DATABASE_URL)
Session = sessionmaker(bind=engine)
session = Session()

Base.metadata.create_all(engine)  # Ensures tables are created
print("✅ Tables created successfully!")

# Verify by listing tables
inspector = inspect(engine)
tables = inspector.get_table_names()
print("Existing tables:", tables)
