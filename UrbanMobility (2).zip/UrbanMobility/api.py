import numpy as np
import requests
import heapq
import math
from typing import List, Dict, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
from sqlalchemy.orm import sessionmaker
from database import DeliveryRequest, Vehicle, TrafficData, WeatherData
from database_manager import init_db
from config import GOOGLE_MAPS_API_KEY

# Initialize Database Session
Session = init_db()

@dataclass
class DeliveryRequestData:
    id: str
    location: Tuple[float, float]
    time_window: Tuple[datetime, datetime]
    load_size: float
    priority: int

@dataclass
class VehicleData:
    id: str
    capacity: float
    current_location: Tuple[float, float]
    available_time: datetime

class DeliveryOptimizer:
    def __init__(self):
        self.vehicles: List[VehicleData] = []
        self.requests: List[DeliveryRequestData] = []
        self.traffic_data: Dict[Tuple[float, float], float] = {}
        self.weather_data: Dict[Tuple[float, float], float] = {}

        # Load initial data from database
        self.load_data_from_db()

    def load_data_from_db(self):
        """Load pending delivery requests and available vehicles from the database"""
        session = Session()
        try:
            self.requests = [
                DeliveryRequestData(
                    id=req.id,
                    location=(req.latitude, req.longitude),
                    time_window=(req.time_window_start, req.time_window_end),
                    load_size=req.load_size,
                    priority=req.priority
                )
                for req in session.query(DeliveryRequest).filter_by(status='pending').all()
            ]

            self.vehicles = [
                VehicleData(
                    id=veh.id,
                    capacity=veh.capacity,
                    current_location=(veh.current_latitude, veh.current_longitude),
                    available_time=veh.available_time
                )
                for veh in session.query(Vehicle).filter_by(status='available').all()
            ]
        finally:
            session.close()

    def get_travel_time(self, start: Tuple[float, float], end: Tuple[float, float]) -> float:
        """Get travel time using Google Maps API, fallback to Haversine if unavailable"""
        lat1, lon1 = start
        lat2, lon2 = end
        url = f"https://maps.googleapis.com/maps/api/distancematrix/json?origins={lat1},{lon1}&destinations={lat2},{lon2}&key={GOOGLE_MAPS_API_KEY}"
        response = requests.get(url)
        data = response.json()

        if 'rows' in data and data['rows'][0]['elements'][0]['status'] == 'OK':
            return data['rows'][0]['elements'][0]['duration']['value'] / 60  # Convert to minutes

        # If API fails, use Haversine formula
        return self.calculate_base_time(start, end)

    def calculate_base_time(self, start: Tuple[float, float], end: Tuple[float, float]) -> float:
        """Calculate travel time using the Haversine formula"""
        lat1, lon1 = start
        lat2, lon2 = end
        R = 6371  # Earth radius in km

        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)

        a = (math.sin(dlat / 2) ** 2 +
             math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
             math.sin(dlon / 2) ** 2)
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

        distance = R * c  # Distance in km
        avg_speed_kph = 40  # Assume average speed of 40 km/h
        return (distance / avg_speed_kph) * 60  # Convert to minutes

    def optimize_routes(self) -> Dict[str, List[DeliveryRequestData]]:
        """Optimize delivery routes using Adaptive Large Neighborhood Search (ALNS)"""
        current_solution = self._generate_initial_solution()
        best_solution = current_solution.copy()
        best_cost = self._evaluate_solution(best_solution)

        temperature = 100
        cooling_rate = 0.95
        iterations = 1000

        for i in range(iterations):
            removed_requests = self._remove_random_requests(current_solution)
            new_solution = self._reinsert_requests(current_solution, removed_requests)

            new_cost = self._evaluate_solution(new_solution)

            if new_cost < best_cost or np.random.random() < np.exp((best_cost - new_cost) / temperature):
                current_solution = new_solution
                if new_cost < best_cost:
                    best_solution = new_solution
                    best_cost = new_cost

            temperature *= cooling_rate

            if i % 10 == 0:
                self._check_and_update_real_time_conditions()

        return best_solution

    def _evaluate_solution(self, solution: Dict[str, List[DeliveryRequestData]]) -> float:
        """Evaluate solution cost based on time, capacity, and priority"""
        total_cost = 0

        for vehicle_id, route in solution.items():
            vehicle = next(v for v in self.vehicles if v.id == vehicle_id)
            current_time = vehicle.available_time
            current_location = vehicle.current_location
            current_load = 0

            for delivery in route:
                travel_time = self.get_travel_time(current_location, delivery.location)
                current_time += timedelta(minutes=travel_time)

                if current_time < delivery.time_window[0]:
                    current_time = delivery.time_window[0]
                elif current_time > delivery.time_window[1]:
                    total_cost += 1000  

                current_load += delivery.load_size
                if current_load > vehicle.capacity:
                    total_cost += 500  

                total_cost += travel_time * (1 + (5 - delivery.priority) * 0.2)
                current_location = delivery.location

        return total_cost

    def _check_and_update_real_time_conditions(self):
        """Update real-time conditions and adjust routes if necessary"""
        session = Session()
        try:
            new_traffic = session.query(TrafficData).order_by(TrafficData.timestamp.desc()).first()
            new_weather = session.query(WeatherData).order_by(WeatherData.timestamp.desc()).first()
            if new_traffic:
                self.traffic_data = {((new_traffic.start_latitude, new_traffic.start_longitude),
                                      (new_traffic.end_latitude, new_traffic.end_longitude)): new_traffic.traffic_factor}
            if new_weather:
                self.weather_data = {(new_weather.latitude, new_weather.longitude): new_weather.weather_factor}
        finally:
            session.close()

    def reoptimize_if_needed(self, current_routes: Dict[str, List[DeliveryRequestData]]) -> Dict[str, List[DeliveryRequestData]]:
        """Reoptimize routes if significant changes in conditions are detected"""
        self._check_and_update_real_time_conditions()
        return self.optimize_routes()
