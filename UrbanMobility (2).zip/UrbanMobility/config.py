DATABASE_URL = "postgresql://postgres:system@localhost:5432/delivery_db"
GOOGLE_MAPS_API_KEY = "AIzaSyDOnTTNyy5A_kxwuCykLBxqt1-lvkgWhuE"
WEATHER_API_KEY = "your_weather_api_key"