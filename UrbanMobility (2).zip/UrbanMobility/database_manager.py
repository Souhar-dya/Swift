from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from database import Base
from config import DATABASE_URL

def init_db():
    engine = create_engine(DATABASE_URL)
    Base.metadata.create_all(engine)
    SessionLocal = sessionmaker(bind=engine)
    return SessionLocal

if __name__ == "__main__":
    init_db()
    print("Database initialized successfully!")
